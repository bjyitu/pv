import SwiftUI

@main
struct PVApp: App {
    @StateObject private var windowManager = UnifiedWindowManager.shared
    
    var body: some Scene {
        WindowGroup {
            StartView()
                .environmentObject(windowManager)
                .onAppear {
                    windowManager.initializeWindow()
                }
        }
        .windowStyle(DefaultWindowStyle())
        .commands {
            SidebarCommands()
            CommandGroup(replacing: .newItem) {
                Button("打开...") {
                    NotificationCenter.default.post(name: UnifiedWindowManager.Notification.selectDirectory, object: nil)
                }
                .keyboardShortcut("o", modifiers: .command)
            }
        }
    }
    
    init() {
        NSApplication.shared.setActivationPolicy(.regular)
    }
}