import SwiftUI
import Foundation

public enum ImageAspectRatio {
    case portrait    // 竖向图 (宽高比 < 0.8)
    case square      // 正方形 (0.8 <= 宽高比 <= 1.2)
    case landscape   // 横向图 (1.2 < 宽高比 <= 2.0)
    case panoramic   // 超宽横向图 (宽高比 > 2.0)
    
    public static func classify(_ aspectRatio: CGFloat) -> ImageAspectRatio {
        if aspectRatio < 0.8 { return .portrait }
        if aspectRatio <= 1.2 { return .square }
        if aspectRatio <= 2.0 { return .landscape }
        return .panoramic
    }
    
    func getWindowMargins() -> (horizontal: CGFloat, vertical: CGFloat) {
        switch self {
        case .portrait:
            return (0, 0)
        case .landscape:
            return (0, 0)
        case .panoramic:
            return (0, 0)
        case .square:
            return (0, 0)
        }
    }
    
    func getLayoutWeight() -> CGFloat {
        switch self {
        case .portrait:
            return 1.1
        case .landscape:
            return 1.0
        case .panoramic:
            return 1.2
        case .square:
            return 0.9
        }
    }
}

class ListLayoutManager {
    
    // 统一高度约束常量
    private enum LayoutConstraints {
        // 最小行高
        static let minRowHeight: CGFloat = 80
        // 最大行高 
        static let maxRowHeight: CGFloat = 300
        // 尝试不同的高度范围（240-300之间）
        static let minRowHeightRange: CGFloat = 240
        static let maxRowHeightRange: CGFloat = 300
        // 尝试不同的图片数量组合
        static let maxImagePerRowNumberTryAgain:Int = 8
        static let maxImagePerRowNumberTryFirst:Int  = 10
    }
    
    struct SmartRow {
        let images: [ImageItem]
        let targetHeight: CGFloat
        let actualSizes: [CGSize]
        let totalWidth: CGFloat
        
        var imageCount: Int { images.count }
    }
    
    struct RowConfiguration {
        let targetHeight: CGFloat
        let actualSizes: [CGSize]
        let totalWidth: CGFloat
        let dominantType: ImageAspectRatio
    }
    
    struct TypeDistribution {
        let dominantType: ImageAspectRatio
        let typeCounts: [ImageAspectRatio: Int]
    }
    
    struct JustifiedLayoutConfig {
        let containerWidth: CGFloat
        let spacing: CGFloat
        let targetRowHeight: CGFloat
        let minRowHeight: CGFloat
        let maxRowHeight: CGFloat
        let lastRowMode: LastRowMode
        
        enum LastRowMode {
            case left
            case justify
            case center
            case mixed
        }
        
        static func `default`(containerWidth: CGFloat, spacing: CGFloat, targetRowHeight: CGFloat) -> JustifiedLayoutConfig {
            return JustifiedLayoutConfig(
                containerWidth: containerWidth,
                spacing: spacing,
                targetRowHeight: targetRowHeight,
                minRowHeight: LayoutConstraints.minRowHeight,
                maxRowHeight: LayoutConstraints.maxRowHeight,
                lastRowMode: .left
            )
        }
    }
    
    
    func createSmartRows(from images: [ImageItem], availableWidth: CGFloat, thumbnailSize: CGFloat) -> [SmartRow] {
        var rows: [SmartRow] = []
        var currentRowImages: [ImageItem] = []
        let spacing: CGFloat = 10
        
        // 真正的智能算法：为每行找到最优高度和组合
        var imageIndex = 0
        while imageIndex < images.count {
            // 为当前位置找到最优行配置
            let optimalRow = findOptimalRow(
                images: Array(images[imageIndex...]),
                availableWidth: availableWidth,
                baseHeight: thumbnailSize,
                spacing: spacing
            )
            
            if !optimalRow.images.isEmpty {
                rows.append(optimalRow)
                imageIndex += optimalRow.images.count
            } else {
                // 保底处理：至少放入一张图片
                currentRowImages.append(images[imageIndex])
                let fallbackRow = createJustifiedRow(
                    images: currentRowImages,
                    availableWidth: availableWidth,
                    targetHeight: thumbnailSize,
                    spacing: spacing
                )
                rows.append(fallbackRow)
                imageIndex += 1
            }
        }
        
        print("=== ListLayoutManager 智能算法 ===")
        print("总行数: \(rows.count)")
        print("可用宽度: \(availableWidth)")
        print("基础高度: \(thumbnailSize)")
        
        for (index, row) in rows.enumerated() {
            let fillRate = (row.totalWidth / availableWidth) * 100
            print("第\(index + 1)行: \(row.images.count)张图片, 总宽度: \(String(format: "%.1f", row.totalWidth)), 填充率: \(String(format: "%.1f", fillRate))%")
        }
        print("=== ListLayoutManager 智能算法结束 ===")
        
        return rows
    }
    
    /// 真正的智能算法：寻找最优行配置
    private func findOptimalRow(images: [ImageItem], availableWidth: CGFloat, baseHeight: CGFloat, spacing: CGFloat) -> SmartRow {
        guard !images.isEmpty else { return SmartRow(images: [], targetHeight: baseHeight, actualSizes: [], totalWidth: 0) }
        
        var bestRow: SmartRow? = nil
        var bestFillRate: CGFloat = 0
        
        // 尝试不同的高度范围（240-300之间）
        let heightRange = stride(from: max(LayoutConstraints.minRowHeightRange, baseHeight * 0.8), through: min(LayoutConstraints.maxRowHeightRange, baseHeight * 1.2), by: 5)

        for targetHeight in heightRange {
            // 尝试不同的图片数量组合
            for imageCount in 1...min(images.count, LayoutConstraints.maxImagePerRowNumberTryFirst) { // 最多15张图片一行
                let testImages = Array(images.prefix(imageCount))
                let testRow = createJustifiedRow(images: testImages, availableWidth: availableWidth, targetHeight: targetHeight, spacing: spacing)
                
                let fillRate = testRow.totalWidth / availableWidth
                
                // 寻找最佳填充率（85%-100%之间）
                if fillRate >= 0.85 && fillRate <= 1.0 {
                    if fillRate > bestFillRate {
                        bestRow = testRow
                        bestFillRate = fillRate
                    }
                }
            }
        }
        
        // 如果找到了合适的配置，返回最佳结果
        if let bestRow = bestRow {
            return bestRow
        }
        
        // 保底：使用基础高度和尽可能多的图片
        let maxImagesPerRow = min(images.count, LayoutConstraints.maxImagePerRowNumberTryAgain)
        var bestFallbackRow: SmartRow? = nil
        var bestFallbackFillRate: CGFloat = 0
        
        for imageCount in stride(from: maxImagesPerRow, through: 1, by: -1) {
            let testImages = Array(images.prefix(imageCount))
            let testRow = createJustifiedRow(images: testImages, availableWidth: availableWidth, targetHeight: baseHeight, spacing: spacing)
            
            let fillRate = testRow.totalWidth / availableWidth
            
            // 如果达到75%标准，直接返回
            if fillRate >= 0.75 && fillRate <= 1.0 {
                return testRow
            }
            
            // 记录最佳的75%方案（即使达不到75%）
            if fillRate > bestFallbackFillRate {
                bestFallbackRow = testRow
                bestFallbackFillRate = fillRate
            }
        }
        
        // 如果找不到75%的方案，返回最佳的75%尝试结果（图片会稍大但避免单图行）
        if let bestFallbackRow = bestFallbackRow {
            return bestFallbackRow
        }
        
        // 最后保底：至少返回一张图片
        return createJustifiedRow(images: [images[0]], availableWidth: availableWidth, targetHeight: baseHeight, spacing: spacing)
    }
    
    private func calculateOptimalRowConfig(
        images: [ImageItem],
        availableWidth: CGFloat,
        spacing: CGFloat,
        thumbnailSize: CGFloat
    ) -> RowConfiguration {
        guard !images.isEmpty else {
            return RowConfiguration(
                targetHeight: thumbnailSize,
                actualSizes: [],
                totalWidth: 0,
                dominantType: .square
            )
        }
        
        return calculateStandardJustifiedRowConfig(
            images: images,
            availableWidth: availableWidth,
            spacing: spacing,
            targetHeight: thumbnailSize
        )
    }
    
    private func calculateStandardJustifiedRowConfig(
        images: [ImageItem],
        availableWidth: CGFloat,
        spacing: CGFloat,
        targetHeight: CGFloat
    ) -> RowConfiguration {
        let aspectRatios = images.map { $0.size.width / $0.size.height }
        let totalAspectRatio = aspectRatios.reduce(0, +)
        
        let availableWidthForImages = availableWidth - spacing * CGFloat(images.count - 1)
        let idealHeight = availableWidthForImages / totalAspectRatio
        
        // 对纵向图进行特殊处理：限制理想高度，避免过度压缩宽度
        let hasPortraitImages = aspectRatios.contains { $0 < 0.8 }
        let adjustedIdealHeight: CGFloat
        
        if hasPortraitImages && images.count > 1 {
            // 如果包含纵向图且是多图组合，使用更合理的高度计算
            let avgAspectRatio = totalAspectRatio / CGFloat(images.count)
            adjustedIdealHeight = availableWidthForImages / (avgAspectRatio * CGFloat(images.count))
        } else {
            adjustedIdealHeight = idealHeight
        }
        
        // 约束高度在合理范围内，但给纵向图更多空间
        let targetHeight = max(LayoutConstraints.minRowHeight, min(LayoutConstraints.maxRowHeight, adjustedIdealHeight))
        
        var actualSizes: [CGSize] = []
        var totalWidth: CGFloat = 0
        
        // 计算每个图片的尺寸
        for (index, _) in images.enumerated() {
            let aspectRatio = aspectRatios[index]
            let imageWidth = targetHeight * aspectRatio
            actualSizes.append(CGSize(width: imageWidth, height: targetHeight))
            totalWidth += imageWidth
        }
        
        totalWidth += spacing * CGFloat(images.count - 1)
        
        // 如果总宽度超出可用宽度，进行等比缩放
        if totalWidth > availableWidth {
            let scale = availableWidth / totalWidth
            let scaledHeight = targetHeight * scale
            
            // 确保缩放后的高度不小于最小高度，且给纵向图合理的显示空间
            if scaledHeight >= LayoutConstraints.minRowHeight {
                // 对纵向图使用更宽松的缩放策略
                let portraitScale = hasPortraitImages ? min(scale, 0.85) : scale
                let finalScale = hasPortraitImages && images.count <= 2 ? portraitScale : scale
                
                actualSizes = actualSizes.map { size in
                    CGSize(width: size.width * finalScale, height: size.height * finalScale)
                }
                return RowConfiguration(
                    targetHeight: targetHeight * finalScale,
                    actualSizes: actualSizes,
                    totalWidth: availableWidth,
                    dominantType: calculateDominantType(images: images)
                )
            }
        }
        
        return RowConfiguration(
            targetHeight: targetHeight,
            actualSizes: actualSizes,
            totalWidth: totalWidth,
            dominantType: calculateDominantType(images: images)
        )
    }
    
    private func createSmartRow(
        images: [ImageItem],
        config: RowConfiguration,
        spacing: CGFloat
    ) -> SmartRow {
        return SmartRow(
            images: images,
            targetHeight: config.targetHeight,
            actualSizes: config.actualSizes,
            totalWidth: config.totalWidth
        )
    }
    
    private func shouldStartNewRow(
        currentImages: [ImageItem],
        rowConfig: RowConfiguration,
        nextImageData: (image: ImageItem, aspectRatio: CGFloat, type: ImageAspectRatio)?,
        availableWidth: CGFloat,
        spacing: CGFloat,
        thumbnailSize: CGFloat
    ) -> Bool {
        guard !currentImages.isEmpty else { return false }
        
        let currentUtilization = rowConfig.totalWidth / availableWidth
        
        // 如果当前利用率超过90%，开始新行
        if currentUtilization > 0.9 {
            return true
        }
        
        guard let nextImageData = nextImageData else { return false }
        
        // 检查当前行是否包含纵向图
        let currentHasPortrait = currentImages.contains { image in
            let aspectRatio = image.size.width / image.size.height
            return aspectRatio < 0.8
        }
        
        // 预测添加下一张图片后的效果
        let testImages = currentImages + [nextImageData.image]
        let testConfig = calculateOptimalRowConfig(
            images: testImages,
            availableWidth: availableWidth,
            spacing: spacing,
            thumbnailSize: thumbnailSize
        )
        
        // 如果添加后高度变化过大或利用率过低，开始新行
        let heightRatio = testConfig.targetHeight / thumbnailSize
        let utilization = testConfig.totalWidth / availableWidth
        
        // 对包含纵向图的行使用更宽松的标准
        if currentHasPortrait {
            return heightRatio < 0.5 || utilization < 0.4
        } else {
            return heightRatio < 0.7 || utilization < 0.6
        }
    }
    
    private func calculateDominantType(images: [ImageItem]) -> ImageAspectRatio {
        let types = images.map { ImageAspectRatio.classify($0.size.width / $0.size.height) }
        let distribution = calculateTypeDistribution(types)
        return distribution.dominantType
    }
    
    private func calculateTypeDistribution(_ types: [ImageAspectRatio]) -> TypeDistribution {
        var typeCounts: [ImageAspectRatio: Int] = [:]
        
        for type in types {
            typeCounts[type, default: 0] += 1
        }
        
        let dominantType = typeCounts.max { $0.value < $1.value }?.key ?? .square
        
        return TypeDistribution(
            dominantType: dominantType,
            typeCounts: typeCounts
        )
    }
    
    
    private func calculateJustifiedRowLayout(
        images: [ImageItem],
        config: JustifiedLayoutConfig
    ) -> RowConfiguration {
        guard !images.isEmpty else {
            return RowConfiguration(
                targetHeight: config.targetRowHeight,
                actualSizes: [],
                totalWidth: 0,
                dominantType: .square
            )
        }
        
        let idealWidths = images.map { image in
            let aspectRatio = image.size.width / image.size.height
            return config.targetRowHeight * aspectRatio
        }
        let totalIdealWidth = idealWidths.reduce(0, +) + config.spacing * CGFloat(images.count - 1)
        
        let scaleFactor = config.containerWidth / totalIdealWidth
        
        let scaledHeight = config.targetRowHeight * scaleFactor
        
        if scaledHeight < config.minRowHeight {
            return createRowWithMinHeight(images: images, config: config)
        } else if scaledHeight > config.maxRowHeight {
            return createRowWithMaxHeight(images: images, config: config)
        } else {
            let actualSizes = idealWidths.map { width in
                CGSize(width: width * scaleFactor, height: scaledHeight)
            }
            
            return RowConfiguration(
                targetHeight: scaledHeight,
                actualSizes: actualSizes,
                totalWidth: config.containerWidth,
                dominantType: calculateDominantType(images: images)
            )
        }
    }
    
    private func createRowWithMinHeight(
        images: [ImageItem],
        config: JustifiedLayoutConfig
    ) -> RowConfiguration {
        let actualSizes = images.map { image in
            let aspectRatio = image.size.width / image.size.height
            let width = config.minRowHeight * aspectRatio
            return CGSize(width: width, height: config.minRowHeight)
        }
        
        let totalWidth = actualSizes.reduce(0) { $0 + $1.width } + config.spacing * CGFloat(images.count - 1)
        
        return RowConfiguration(
            targetHeight: config.minRowHeight,
            actualSizes: actualSizes,
            totalWidth: totalWidth,
            dominantType: calculateDominantType(images: images)
        )
    }
    
    private func createRowWithMaxHeight(
        images: [ImageItem],
        config: JustifiedLayoutConfig
    ) -> RowConfiguration {
        var actualSizes: [CGSize] = []
        var totalWidth: CGFloat = 0
        
        for image in images {
            let aspectRatio = image.size.width / image.size.height
            let width = config.maxRowHeight * aspectRatio
            let size = CGSize(width: width, height: config.maxRowHeight)
            
            let potentialTotalWidth = totalWidth + width + (actualSizes.isEmpty ? 0 : config.spacing)
            
            if actualSizes.isEmpty || potentialTotalWidth <= config.containerWidth * 1.2 {
                actualSizes.append(size)
                totalWidth = potentialTotalWidth
            } else {
                break
            }
        }
        
        return RowConfiguration(
            targetHeight: config.maxRowHeight,
            actualSizes: actualSizes,
            totalWidth: totalWidth,
            dominantType: calculateDominantType(images: images)
        )
    }
    
    private func handleLastRow(
        images: [ImageItem],
        config: JustifiedLayoutConfig
    ) -> RowConfiguration {
        return calculateJustifiedRowLayout(images: images, config: config)
    }
    
    
    private func calculateDynamicTargetHeight(availableWidth: CGFloat, baseHeight: CGFloat) -> CGFloat {
        // 基于窗口宽度动态调整目标高度
        // 窗口越宽，目标高度适当增加，但保持在合理范围内
        let widthFactor = min(availableWidth / 1200.0, 1.5) // 最大1.5倍调整
        let dynamicHeight = baseHeight * widthFactor
        return max(LayoutConstraints.minRowHeight, min(LayoutConstraints.maxRowHeight, dynamicHeight))
    }
    
    private func calculateRowIdealWidth(images: [ImageItem], targetHeight: CGFloat, spacing: CGFloat) -> CGFloat {
        // 计算当前行在目标高度下的总理想宽度
        let totalImageWidth = images.reduce(0.0) { sum, image in
            let aspectRatio = image.size.width / image.size.height
            return sum + (targetHeight * aspectRatio)
        }
        let totalSpacing = spacing * CGFloat(max(0, images.count - 1))
        return totalImageWidth + totalSpacing
    }
    
    private func createJustifiedRow(images: [ImageItem], availableWidth: CGFloat, targetHeight: CGFloat, spacing: CGFloat) -> SmartRow {
        let aspectRatios = images.map { $0.size.width / $0.size.height }
        let idealWidths = aspectRatios.map { $0 * targetHeight }
        let totalIdealWidth = idealWidths.reduce(0, +) + spacing * CGFloat(max(0, images.count - 1))
        
        // 计算缩放因子
        let scaleFactor = availableWidth / totalIdealWidth
        let finalHeight = targetHeight * scaleFactor
        
        // 确保高度在合理范围内
        let clampedHeight = max(LayoutConstraints.minRowHeight, min(LayoutConstraints.maxRowHeight, finalHeight))
        let finalScaleFactor = clampedHeight / targetHeight
        
        // 计算最终尺寸
        let actualSizes = idealWidths.map { width in
            CGSize(width: width * finalScaleFactor, height: clampedHeight)
        }
        
        let finalTotalWidth = actualSizes.reduce(0) { $0 + $1.width } + spacing * CGFloat(max(0, images.count - 1))
        
        return SmartRow(
            images: images,
            targetHeight: clampedHeight,
            actualSizes: actualSizes,
            totalWidth: finalTotalWidth
        )
    }
}